import UIKit

// Задачи с первой главы книги

var myAge: Int = 28
var dogs: Int = 0
dogs + 1

var age: Int = 16
print(age)
age = 30
print(age)

let x: Int = 46
let y: Int = 10


let answer1: Int = (x * 100) + y
let answer2: Int = (x * 100) + (y * 100)
let answer3: Int = (x * 100) + (y / 10)

8-(4*2)+6/3*4

let rating1: Double = 4
let rating2: Double = 2
let rating3: Double = 5
let averageRating: Double = (rating1 + rating2 + rating3) / 3

let Voltage: Double = 1.3
let current: Double = 1.8
let power: Double = Voltage * current

let resistance: Double = power / (Voltage*current)

let randomNumber = arc4random()
let diceRoll = 1 + randomNumber % 6

let a: Double = 4.0
let b: Double = 7.0
let c: Double = 3.0
let root1: Double = (-b + (b*b - 4*a*c).squareRoot()) / (2*a)
let root2: Double = (-b - (b*b - 4*a*c).squareRoot()) / (2*a)


// Впорос 1
// let, var, Int, String, UInt, Double, Float

// Вопрос 2
let intMin = Int.min
let intMax = Int.max

let UIntMin = UInt.min
let UIntMax = UInt.max

// Вопрос 3
typealias Count = Int
var oneProduct = (name: "Milk", sum: 2)
var twoProduct = (name: "Beer", sum: 3)
var threeProduct = (name: "Chiken", sum: 7)

// Вопрос 4
let f = 12
let o = Double(f)
print(o)

let p = 23.56
let l = Int(p)

let m = 35.4
let n = UInt(m)

let h = 35
let j = Float(m)
